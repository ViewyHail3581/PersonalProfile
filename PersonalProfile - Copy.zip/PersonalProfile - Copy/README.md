
# PersonalProfile Web App

A single-page web application to manage and display personal information, skills, experience, education, and projects — similar to a LinkedIn profile. The app includes full CRUD functionality through a C# Web API, a class library for separation of concerns, and a ReactJS frontend.

---

## 🛠️ Tech Stack

- **Frontend**: ReactJS (Vite or Create React App)
- **Backend**: ASP.NET Core Web API (.NET 8)
- **Class Library**: C# (for domain models and services)
- **Database (Planned)**: SQL Server Project in Visual Studio

---

## 📁 Project Structure

```
PersonalProfileSolution/
├── PersonalProfile.Domain/         # Domain models (C# class library)
├── PersonalProfile.Services/       # Service interfaces & logic (C# class library)
├── PersonalProfile.API/            # ASP.NET Core Web API
├── PersonalProfile.DatabaseScripts/
│   ├── CreateTables.sql
│   ├── InsertSampleData.sql
│   └── StoredProcedures.sql
└── personal-profile-frontend/      # ReactJS frontend app
```

---

## ✅ Features

- Full CRUD support for:
  - Personal Info
  - Skills
  - Experience
  - Education
  - Projects
- Fully connected Web API (controllers + service layer)
- Frontend supports real-time interaction, editing, deleting, and adding entries
- Mock data fallback for testing when backend is unavailable

---

## ❌ Database Issue (SQL Server Data Tools)

### 💥 The Problem

The Visual Studio **SQL Server Data Tools (SDK Style)** required to create a deployable database project did **not load correctly**, despite repeated troubleshooting attempts.

### 📷 Error Message

> _"The 'Microsoft SQL Server Data Tools (SDK Style)' package did not load correctly..."_

![SQL SDK Error](./screenshots/sql-sdk-error.png)

### 🧪 Troubleshooting Actions Taken

- ✅ Attempted to **repair** Visual Studio
- ✅ Uninstalled and **reinstalled SQL Server Data Tools**
- ✅ Performed a full **reinstall of Visual Studio 2022 Community**
- ✅ Tried **fresh installation** of all individual components (including database features)
- ✅ Created a new project after reinstall
- ❌ **Still received the same error** after every attempt

### ✅ Workaround

Since the database project could not be created in Visual Studio:

- SQL scripts for `CREATE TABLE`, `INSERT`, and `STORED PROCEDURES` were written manually.
- The database component was **excluded from the running application**, but all logic for API and frontend data handling was kept intact.
- The frontend was modified to use **mock data**, while preserving the structure and fetch logic for easy API replacement later.

---

## 🚀 Getting Started

### 1. Backend (ASP.NET Core)

1. Open `PersonalProfile.API` in Visual Studio
2. Run the project (`Ctrl + F5`)
3. Swagger UI will be available at:  
   `https://localhost:7206/swagger/index.html`

### 2. Frontend (ReactJS)

```bash
cd personal-profile-frontend
npm install
npm run dev    # or `npm start` for CRA
```

Access the app at:  
`http://localhost:3000`

---

## 💻 Mock Data for Testing

Because the DB was not operational:

- API fetch calls are **commented out** in `App.js`
- Corresponding **mock logic** is included right after each fetch call
- All functionality (edit, add, delete) works exactly as if data were fetched from a live server

To switch to a real backend:
1. Ensure backend is running and reachable
2. Uncomment the fetch calls in `App.js`
3. Remove or replace mock logic

---

## 📃 Database Scripts (For Reference)

Even though SQL couldn't be deployed, you’ll find:

- `CreateTables.sql`
- `InsertSampleData.sql`
- `StoredProcedures.sql`

These scripts are complete and demonstrate an understanding of schema design and stored procedures.

---

## ✨ Highlights

- ✔️ Separation of concerns via class libraries
- ✔️ C# best practices and async service interfaces
- ✔️ React app with routing, state, and event handling
- ✔️ Honest fallback strategy due to system issues
- ✔️ Transparent documentation of all limitations

---

## ✉️ Author Info

**Eugene du Toit**  
📧 eugene@example.com  
🌍 South Africa
