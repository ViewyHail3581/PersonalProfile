﻿using Microsoft.AspNetCore.Mvc;
using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;

namespace PersonalProfile.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EducationController : ControllerBase
    {
        private readonly IEducationService _educationService;

        public EducationController(IEducationService educationService)
        {
            _educationService = educationService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var education = await _educationService.GetAllEducationAsync();
            return Ok(education);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var item = await _educationService.GetEducationAsync(id);
            if (item == null)
                return NotFound();

            return Ok(item);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Education education)
        {
            await _educationService.AddEducationAsync(education);
            return CreatedAtAction(nameof(Get), new { id = education.Id }, education);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Education education)
        {
            if (id != education.Id)
                return BadRequest("ID mismatch");

            await _educationService.UpdateEducationAsync(education);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _educationService.DeleteEducationAsync(id);
            return NoContent();
        }
    }
}
