﻿using Microsoft.AspNetCore.Mvc;
using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;

namespace PersonalProfile.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PersonalInfoController : ControllerBase
    {
        private readonly IPersonalInfoService _personalInfoService;

        public PersonalInfoController(IPersonalInfoService personalInfoService)
        {
            _personalInfoService = personalInfoService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var infoList = await _personalInfoService.GetAllPersonalInfoAsync();
            return Ok(infoList);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var info = await _personalInfoService.GetPersonalInfoAsync(id);
            if (info == null)
                return NotFound();

            return Ok(info);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] PersonalInfo info)
        {
            await _personalInfoService.AddPersonalInfoAsync(info);
            return CreatedAtAction(nameof(Get), new { id = info.Id }, info);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] PersonalInfo info)
        {
            if (id != info.Id)
                return BadRequest("ID mismatch");

            await _personalInfoService.UpdatePersonalInfoAsync(info);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _personalInfoService.DeletePersonalInfoAsync(id);
            return NoContent();
        }
    }
}
