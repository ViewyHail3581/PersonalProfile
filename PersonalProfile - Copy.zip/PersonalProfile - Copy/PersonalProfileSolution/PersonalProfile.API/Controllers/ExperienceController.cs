﻿using Microsoft.AspNetCore.Mvc;
using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;

namespace PersonalProfile.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ExperienceController : ControllerBase
    {
        private readonly IExperienceService _experienceService;

        public ExperienceController(IExperienceService experienceService)
        {
            _experienceService = experienceService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var experience = await _experienceService.GetAllExperienceAsync();
            return Ok(experience);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var item = await _experienceService.GetExperienceAsync(id);
            if (item == null)
                return NotFound();

            return Ok(item);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Experience experience)
        {
            await _experienceService.AddExperienceAsync(experience);
            return CreatedAtAction(nameof(Get), new { id = experience.Id }, experience);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Experience experience)
        {
            if (id != experience.Id)
                return BadRequest("ID mismatch");

            await _experienceService.UpdateExperienceAsync(experience);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            await _experienceService.DeleteExperienceAsync(id);
            return NoContent();
        }
    }
}
