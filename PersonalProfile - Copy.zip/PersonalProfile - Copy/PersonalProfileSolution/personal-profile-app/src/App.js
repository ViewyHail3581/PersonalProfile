// App.js
import React, { useEffect, useState } from 'react';
import './App.css';

function App() {
  const [isEditing, setIsEditing] = useState(false);
  const [personalInfo, setPersonalInfo] = useState({
    id: 1,
    fullName: '',
    email: '',
    phone: '',
    bio: '',
    location: '',
  });

  const [skills, setSkills] = useState([]);
  const [newSkill, setNewSkill] = useState('');

  const [experienceList, setExperienceList] = useState([]);
  const [newExperience, setNewExperience] = useState({
    title: '',
    company: '',
    duration: '',
    description: '',
  });

  const [education, setEducation] = useState([]);
  const [newEducation, setNewEducation] = useState({
    institution: '',
    degree: '',
    startYear: '',
    endYear: '',
  });

  const [projects, setProjects] = useState([]);
  const [newProject, setNewProject] = useState({
    title: '',
    description: '',
    techStack: '', 
  });

  // === Fetch Data (mocked fallback below each) ===
  useEffect(() => {
    // fetch('https://localhost:7206/api/personalinfo/1')
    //   .then(res => res.json())
    //   .then(data => setPersonalInfo(data));

    setPersonalInfo({
      id: 1,
      fullName: 'Eugene du Toit',
      email: 'e.dutoit.sa@gmail.com',
      phone: '071 896 8361',
      bio: 'Software developer passionate about fullstack engineering.',
      location: 'South Africa',
    });

    // fetch('https://localhost:7206/api/skills')
    //   .then(res => res.json())
    //   .then(data => setSkills(data));

    setSkills(['React', 'C#', 'SQL']);

    // fetch('https://localhost:7206/api/experience')
    //   .then(res => res.json())
    //   .then(data => setExperienceList(data));

    setExperienceList([
      {
        id: 1,
        title: 'Lead Software Developer',
        company: 'IBEWA',
        duration: 'Jun 2023 – Present',
        description: 'Working on full web management software.',
      },
    ]);

    // fetch('https://localhost:7206/api/education')
    //   .then(res => res.json())
    //   .then(data => setEducation(data));

    setEducation([
      {
        id: 1,
        institution: 'UNISA',
        degree: 'BSc Computer Science',
        startYear: '2022',
        endYear: '2025',
      },
    ]);

    // fetch('https://localhost:7206/api/projects')
    //   .then(res => res.json())
    //   .then(data => setProjects(data));

    setProjects([
      {
        id: 1,
        title: 'Portfolio Website',
        description: 'Built with React and .NET backend.',
        techStack: 'React, C#, SQL',
      },
    ]);
  }, []);

  // === Handlers ===
  const toggleEdit = () => setIsEditing(!isEditing);

  const handlePersonalInfoChange = (e) => {
    const { name, value } = e.target;
    setPersonalInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleAddSkill = () => {
    if (newSkill.trim()) {
      setSkills([...skills, newSkill.trim()]);
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (index) => {
    setSkills(skills.filter((_, i) => i !== index));
  };

  const handleExperienceChange = (e) => {
    const { name, value } = e.target;
    setNewExperience(prev => ({ ...prev, [name]: value }));
  };

  const addExperience = () => {
    if (newExperience.title && newExperience.company && newExperience.duration) {
      const newEntry = { ...newExperience, id: Date.now() };
      setExperienceList([...experienceList, newEntry]);
      setNewExperience({ title: '', company: '', duration: '', description: '' });
    }
  };

  const removeExperience = (id) => {
    setExperienceList(experienceList.filter((exp) => exp.id !== id));
  };

  const handleEducationChange = (e) => {
    const { name, value } = e.target;
    setNewEducation(prev => ({ ...prev, [name]: value }));
  };

  const handleAddEducation = () => {
    if (newEducation.institution && newEducation.degree) {
      const newEntry = { ...newEducation, id: Date.now() };
      setEducation([...education, newEntry]);
      setNewEducation({ institution: '', degree: '', startYear: '', endYear: '' });
    }
  };

  const handleDeleteEducation = (id) => {
    setEducation(education.filter(edu => edu.id !== id));
  };

  const handleProjectChange = (e) => {
    const { name, value } = e.target;
    setNewProject(prev => ({ ...prev, [name]: value }));
  };

  const handleAddProject = () => {
    if (newProject.title && newProject.description) {
      const newEntry = { ...newProject, id: Date.now() };
      setProjects([...projects, newEntry]);
      setNewProject({ title: '', description: '', techStack: '' });
    }
  };

  const handleDeleteProject = (id) => {
    setProjects(projects.filter(proj => proj.id !== id));
  };

  // === Render ===
  return (
    <div className="container">
      <h1>My Personal Profile</h1>

      <nav className="navbar">
        <a href="#personal-info">Personal Info</a>
        <a href="#skills">Skills</a>
        <a href="#experience">Experience</a>
        <a href="#education">Education</a>
        <a href="#projects">Projects</a>
      </nav>

      <section id="personal-info">
        <h2>Personal Information</h2>
        {isEditing ? (
          <div className="personal-info-form">
            <div className="grid-layout">
            <input name="fullName" value={personalInfo.fullName} onChange={handlePersonalInfoChange} placeholder="Full Name" />
            <input name="email" value={personalInfo.email} onChange={handlePersonalInfoChange} placeholder="Email" />
            <input name="phone" value={personalInfo.phone} onChange={handlePersonalInfoChange} placeholder="Phone" />
            <input name="location" value={personalInfo.location} onChange={handlePersonalInfoChange} placeholder="Location" />
            </div>
            <textarea name="bio" value={personalInfo.bio} onChange={handlePersonalInfoChange} placeholder="Short Bio" />
            <button className="text-button" onClick={toggleEdit}>Save</button>
          </div>
        ) : (
          <div className="personal-info-display">
            <p><strong>Name:</strong> {personalInfo.fullName}</p>
            <p><strong>Email:</strong> {personalInfo.email}</p>
            <p><strong>Phone:</strong> {personalInfo.phone}</p>
            <p><strong>Location:</strong> {personalInfo.location}</p>
            <p><strong>Bio:</strong> {personalInfo.bio}</p>
            <button className="text-button" onClick={toggleEdit}>Edit</button>
          </div>
        )}
      </section>

      <section id="skills">
        <h2>Skills</h2>
        <ul className="skills-flex">
          {skills.map((skill, index) => (
            <li key={index}>
              {skill} <button className='solo-icon-button' onClick={() => handleRemoveSkill(index)}>❌</button>
            </li>
          ))}
        </ul>
        <input type="text" value={newSkill} onChange={(e) => setNewSkill(e.target.value)} placeholder="New skill" />
        <button className="text-button" onClick={handleAddSkill}>Add Skill</button>
      </section>

      <section id="experience">
        <h2>Experience</h2>
        {experienceList.map((exp) => (
          <div key={exp.id} className="experience-card">
            <h3>{exp.title} @ {exp.company}</h3>
            <p><strong>Duration:</strong> {exp.duration}</p>
            <p>{exp.description}</p>
            <button className="text-button" onClick={() => removeExperience(exp.id)}>❌ Delete</button>
          </div>
        ))}
        <div className="experience-form">
          <div className="grid-layout">
          <input name="title" value={newExperience.title} onChange={handleExperienceChange} placeholder="Job Title" />
          <input name="company" value={newExperience.company} onChange={handleExperienceChange} placeholder="Company" />
          <input name="duration" value={newExperience.duration} onChange={handleExperienceChange} placeholder="Duration" />
          </div>
          <textarea name="description" value={newExperience.description} onChange={handleExperienceChange} placeholder="Description" />
          <button className="text-button" onClick={addExperience}>Add Experience</button>
        </div>
      </section>

      <section id="education">
        <h2>Education</h2>
        <ul>
          {education.map((edu) => (
            <li key={edu.id}>
              <strong>{edu.degree}</strong> at {edu.institution} ({edu.startYear} - {edu.endYear})
              <button className="text-button" onClick={() => handleDeleteEducation(edu.id)}>❌ Delete</button>
            </li>
          ))}
        </ul>
        <div className="education-form">
          <div className="grid-layout">
          <input name="institution" value={newEducation.institution} onChange={handleEducationChange} placeholder="Institution" />
          <input name="degree" value={newEducation.degree} onChange={handleEducationChange} placeholder="Degree" />
          <input name="startYear" value={newEducation.startYear} onChange={handleEducationChange} placeholder="Start Year" />
          <input name="endYear" value={newEducation.endYear} onChange={handleEducationChange} placeholder="End Year" />
          </div>
          <button className="text-button" onClick={handleAddEducation}>Add Education</button>
        </div>
      </section>

      <section id="projects">
        <h2>Projects</h2>
        <ul>
          {projects.map((proj) => (
            <li key={proj.id}>
              <strong>{proj.title}</strong> – <em>Tech Stack:</em> {proj.techStack}<br />
              - <em>Description:</em> {proj.description}<br />
              
              <button className="text-button" onClick={() => handleDeleteProject(proj.id)}>❌ Delete</button>
            </li>
          ))}
        </ul>
        <div className="project-form">
          <div className="grid-layout">
          <input name="title" value={newProject.title} onChange={handleProjectChange} placeholder="Project Title" />
          <input name="techStack" value={newProject.techStack} onChange={handleProjectChange} placeholder="Tech Stack" />
          </div>
          <textarea name="description" value={newProject.description} onChange={handleProjectChange} placeholder="Description" />
          <button className="text-button" onClick={handleAddProject}>Add Project</button>
        </div>
      </section>
    </div>
  );
}

export default App;
