﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalProfile.Domain.Models
{
    public class Education
    {
        public int Id { get; set; }  // primary key
        public string Institution { get; set; } = string.Empty;
        public string Degree { get; set; } = string.Empty;
        public string StartYear { get; set; } = string.Empty;
        public string EndYear { get; set; } = string.Empty;
    }
}

