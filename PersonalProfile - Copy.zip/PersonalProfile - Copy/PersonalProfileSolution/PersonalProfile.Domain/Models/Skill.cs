﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalProfile.Domain.Models
{
    public class Skill
    {
        public int Id { get; set; }  // primary key
        public string Name { get; set; } = string.Empty;
    }
}

