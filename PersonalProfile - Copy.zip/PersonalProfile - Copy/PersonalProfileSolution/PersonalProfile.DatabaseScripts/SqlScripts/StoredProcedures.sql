-- ============================================
-- STORED PROCEDURES FOR: Skills
-- ============================================

CREATE PROCEDURE sp_GetAllSkills
AS
BEGIN
    SELECT * FROM Skills;
END;
GO

CREATE PROCEDURE sp_GetSkillById @Id INT
AS
BEGIN
    SELECT * FROM Skills WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_AddSkill @Name NVARCHAR(100)
AS
BEGIN
    INSERT INTO Skills (Name) VALUES (@Name);
END;
GO

CREATE PROCEDURE sp_UpdateSkill @Id INT, @Name NVARCHAR(100)
AS
BEGIN
    UPDATE Skills SET Name = @Name WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_DeleteSkill @Id INT
AS
BEGIN
    DELETE FROM Skills WHERE Id = @Id;
END;
GO

-- ============================================
-- STORED PROCEDURES FOR: Education
-- ============================================

CREATE PROCEDURE sp_GetAllEducation
AS
BEGIN
    SELECT * FROM Education;
END;
GO

CREATE PROCEDURE sp_GetEducationById @Id INT
AS
BEGIN
    SELECT * FROM Education WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_AddEducation
    @Institution NVARCHAR(255),
    @Degree NVARCHAR(255),
    @StartYear NVARCHAR(50),
    @EndYear NVARCHAR(50)
AS
BEGIN
    INSERT INTO Education (Institution, Degree, StartYear, EndYear)
    VALUES (@Institution, @Degree, @StartYear, @EndYear);
END;
GO

CREATE PROCEDURE sp_UpdateEducation
    @Id INT,
    @Institution NVARCHAR(255),
    @Degree NVARCHAR(255),
    @StartYear NVARCHAR(50),
    @EndYear NVARCHAR(50)
AS
BEGIN
    UPDATE Education
    SET Institution = @Institution,
        Degree = @Degree,
        StartYear = @StartYear,
        EndYear = @EndYear
    WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_DeleteEducation @Id INT
AS
BEGIN
    DELETE FROM Education WHERE Id = @Id;
END;
GO

-- ============================================
-- STORED PROCEDURES FOR: Experience
-- ============================================

CREATE PROCEDURE sp_GetAllExperience
AS
BEGIN
    SELECT * FROM Experience;
END;
GO

CREATE PROCEDURE sp_GetExperienceById @Id INT
AS
BEGIN
    SELECT * FROM Experience WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_AddExperience
    @Title NVARCHAR(255),
    @Company NVARCHAR(255),
    @Duration NVARCHAR(100),
    @Description NVARCHAR(MAX)
AS
BEGIN
    INSERT INTO Experience (Title, Company, Duration, Description)
    VALUES (@Title, @Company, @Duration, @Description);
END;
GO

CREATE PROCEDURE sp_UpdateExperience
    @Id INT,
    @Title NVARCHAR(255),
    @Company NVARCHAR(255),
    @Duration NVARCHAR(100),
    @Description NVARCHAR(MAX)
AS
BEGIN
    UPDATE Experience
    SET Title = @Title,
        Company = @Company,
        Duration = @Duration,
        Description = @Description
    WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_DeleteExperience @Id INT
AS
BEGIN
    DELETE FROM Experience WHERE Id = @Id;
END;
GO

-- ============================================
-- STORED PROCEDURES FOR: Projects
-- ============================================

CREATE PROCEDURE sp_GetAllProjects
AS
BEGIN
    SELECT * FROM Projects;
END;
GO

CREATE PROCEDURE sp_GetProjectById @Id INT
AS
BEGIN
    SELECT * FROM Projects WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_AddProject
    @Title NVARCHAR(255),
    @Description NVARCHAR(MAX),
    @TechStack NVARCHAR(255)
AS
BEGIN
    INSERT INTO Projects (Title, Description, TechStack)
    VALUES (@Title, @Description, @TechStack);
END;
GO

CREATE PROCEDURE sp_UpdateProject
    @Id INT,
    @Title NVARCHAR(255),
    @Description NVARCHAR(MAX),
    @TechStack NVARCHAR(255)
AS
BEGIN
    UPDATE Projects
    SET Title = @Title,
        Description = @Description,
        TechStack = @TechStack
    WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_DeleteProject @Id INT
AS
BEGIN
    DELETE FROM Projects WHERE Id = @Id;
END;
GO

-- ============================================
-- STORED PROCEDURES FOR: PersonalInfo
-- ============================================

CREATE PROCEDURE sp_GetAllPersonalInfo
AS
BEGIN
    SELECT * FROM PersonalInfo;
END;
GO

CREATE PROCEDURE sp_GetPersonalInfoById @Id INT
AS
BEGIN
    SELECT * FROM PersonalInfo WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_AddPersonalInfo
    @FullName NVARCHAR(255),
    @Email NVARCHAR(255),
    @Phone NVARCHAR(100),
    @Bio NVARCHAR(MAX),
    @Location NVARCHAR(255)
AS
BEGIN
    INSERT INTO PersonalInfo (FullName, Email, Phone, Bio, Location)
    VALUES (@FullName, @Email, @Phone, @Bio, @Location);
END;
GO

CREATE PROCEDURE sp_UpdatePersonalInfo
    @Id INT,
    @FullName NVARCHAR(255),
    @Email NVARCHAR(255),
    @Phone NVARCHAR(100),
    @Bio NVARCHAR(MAX),
    @Location NVARCHAR(255)
AS
BEGIN
    UPDATE PersonalInfo
    SET FullName = @FullName,
        Email = @Email,
        Phone = @Phone,
        Bio = @Bio,
        Location = @Location
    WHERE Id = @Id;
END;
GO

CREATE PROCEDURE sp_DeletePersonalInfo @Id INT
AS
BEGIN
    DELETE FROM PersonalInfo WHERE Id = @Id;
END;
GO
