INSERT INTO Skills (Name) VALUES ("React"), ("C#"), ("SQL");

INSERT INTO Education (Institution, Degree, StartYear, EndYear)
VALUES ("University of Cape Town", "BSc Computer Science", "2018", "2021");

INSERT INTO Experience (Title, Company, Duration, Description)
VALUES ("Software Developer", "Newsclip", "Jan 2022 � Present", "Worked on full-stack apps.");

INSERT INTO Projects (Title, Description, TechStack)
VALUES ("Portfolio Site", "React-based site for personal profile", "React, CSS, GitHub Pages");

INSERT INTO PersonalInfo (FullName, Email, Phone, Bio, Location)
VALUES ("Eugene du Toit", "eugene@example.com", "000-000-0000", "Dev passionate about clean code.", "South Africa");
