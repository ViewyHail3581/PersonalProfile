CREATE TABLE Skills (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL
);

CREATE TABLE Education (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Institution NVARCHAR(200) NOT NULL,
    Degree NVARCHAR(200) NOT NULL,
    StartYear NVARCHAR(10),
    EndYear NVARCHAR(10)
);


CREATE TABLE Experience (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200) NOT NULL,
    Company NVARCHAR(200) NOT NULL,
    Duration NVARCHAR(100),
    Description NVARCHAR(MAX)
);

CREATE TABLE Projects (
    Id INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(200) NOT NULL,
    Description NVARCHAR(MAX),
    TechStack NVARCHAR(300)
);

CREATE TABLE PersonalInfo (
    Id INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(200) NOT NULL,
    Email NVARCHAR(200),
    Phone NVARCHAR(50),
    Bio NVARCHAR(MAX),
    Location NVARCHAR(200)
);
