-- Publish.sql
-- Master script to execute all setup files

--:r .\CreateTables.sql
--:r .\InsertSampleData.sql
--:r .\StoredProcedures.sql
