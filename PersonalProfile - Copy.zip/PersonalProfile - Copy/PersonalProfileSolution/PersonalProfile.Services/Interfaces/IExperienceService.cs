﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Interfaces
{
    public interface IExperienceService
    {
        Task<Experience?> GetExperienceAsync(int id);
        Task<IEnumerable<Experience>> GetAllExperienceAsync();
        Task AddExperienceAsync(Experience experience);
        Task UpdateExperienceAsync(Experience experience);
        Task DeleteExperienceAsync(int id);
    }
}

