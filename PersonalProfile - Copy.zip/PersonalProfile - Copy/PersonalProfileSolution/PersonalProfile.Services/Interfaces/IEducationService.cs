﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Interfaces
{
    public interface IEducationService
    {
        Task<Education?> GetEducationAsync(int id);
        Task<IEnumerable<Education>> GetAllEducationAsync();
        Task AddEducationAsync(Education education);
        Task UpdateEducationAsync(Education education);
        Task DeleteEducationAsync(int id);
    }
}

