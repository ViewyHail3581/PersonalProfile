﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Interfaces
{
    public interface ISkillService
    {
        Task<Skill?> GetSkillAsync(int id);
        Task<IEnumerable<Skill>> GetAllSkillsAsync();
        Task AddSkillAsync(Skill skill);
        Task UpdateSkillAsync(Skill skill);
        Task DeleteSkillAsync(int id);
    }
}
