﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Implementations
{
    public class ExperienceService : IExperienceService
    {
        private readonly List<Experience> _experiences = new();

        public Task<Experience?> GetExperienceAsync(int id)
        {
            var experience = _experiences.FirstOrDefault(e => e.Id == id);
            return Task.FromResult(experience);
        }

        public Task<IEnumerable<Experience>> GetAllExperienceAsync()
        {
            return Task.FromResult<IEnumerable<Experience>>(_experiences);
        }

        public Task AddExperienceAsync(Experience experience)
        {
            experience.Id = _experiences.Count > 0 ? _experiences.Max(e => e.Id) + 1 : 1;
            _experiences.Add(experience);
            return Task.CompletedTask;
        }

        public Task UpdateExperienceAsync(Experience experience)
        {
            var existing = _experiences.FirstOrDefault(e => e.Id == experience.Id);
            if (existing != null)
            {
                existing.Company = experience.Company;
                existing.Title = experience.Title;
                existing.Duration = experience.Duration;
                existing.Description = experience.Description;
            }
            return Task.CompletedTask;
        }

        public Task DeleteExperienceAsync(int id)
        {
            var experience = _experiences.FirstOrDefault(e => e.Id == id);
            if (experience != null)
            {
                _experiences.Remove(experience);
            }
            return Task.CompletedTask;
        }
    }
}
