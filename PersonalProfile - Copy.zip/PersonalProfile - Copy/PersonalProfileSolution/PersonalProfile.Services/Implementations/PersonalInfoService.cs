﻿using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;

namespace PersonalProfile.Services.Implementations
{
    public class PersonalInfoService : IPersonalInfoService
    {
        private readonly List<PersonalInfo> _personalInfos = new();

        public Task AddPersonalInfoAsync(PersonalInfo info)
        {
            _personalInfos.Add(info);
            return Task.CompletedTask;
        }

        public Task DeletePersonalInfoAsync(int id)
        {
            var item = _personalInfos.FirstOrDefault(p => p.Id == id);
            if (item != null)
                _personalInfos.Remove(item);
            return Task.CompletedTask;
        }

        public Task<IEnumerable<PersonalInfo>> GetAllPersonalInfoAsync()
        {
            return Task.FromResult<IEnumerable<PersonalInfo>>(_personalInfos);
        }

        public Task<PersonalInfo?> GetPersonalInfoAsync(int id)
        {
            var item = _personalInfos.FirstOrDefault(p => p.Id == id);
            return Task.FromResult(item);
        }

        public Task UpdatePersonalInfoAsync(PersonalInfo info)
        {
            var item = _personalInfos.FirstOrDefault(p => p.Id == info.Id);
            if (item != null)
            {
                item.FullName = info.FullName;
                item.Email = info.Email;
                item.Location = info.Location;
            }
            return Task.CompletedTask;
        }
    }
}

