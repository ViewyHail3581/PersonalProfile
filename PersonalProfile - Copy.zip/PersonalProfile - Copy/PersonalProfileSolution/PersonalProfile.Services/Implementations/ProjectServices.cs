﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Implementations
{
    public class ProjectService : IProjectService
    {
        private readonly List<Project> _projects = new();

        public Task<Project?> GetProjectAsync(int id)
        {
            var project = _projects.FirstOrDefault(p => p.Id == id);
            return Task.FromResult(project);
        }

        public Task<IEnumerable<Project>> GetAllProjectsAsync()
        {
            return Task.FromResult<IEnumerable<Project>>(_projects);
        }

        public Task AddProjectAsync(Project project)
        {
            project.Id = _projects.Count > 0 ? _projects.Max(p => p.Id) + 1 : 1;
            _projects.Add(project);
            return Task.CompletedTask;
        }

        public Task UpdateProjectAsync(Project project)
        {
            var existing = _projects.FirstOrDefault(p => p.Id == project.Id);
            if (existing != null)
            {
                existing.Title = project.Title;
                existing.Description = project.Description;
                existing.TechStack = project.TechStack;
            }
            return Task.CompletedTask;
        }

        public Task DeleteProjectAsync(int id)
        {
            var project = _projects.FirstOrDefault(p => p.Id == id);
            if (project != null)
            {
                _projects.Remove(project);
            }
            return Task.CompletedTask;
        }
    }
}

