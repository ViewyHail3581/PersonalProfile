﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Implementations
{
    public class EducationService : IEducationService
    {
        private readonly List<Education> _educations = new();

        public Task<Education?> GetEducationAsync(int id)
        {
            var education = _educations.FirstOrDefault(e => e.Id == id);
            return Task.FromResult(education);
        }

        public Task<IEnumerable<Education>> GetAllEducationAsync()
        {
            return Task.FromResult<IEnumerable<Education>>(_educations);
        }

        public Task AddEducationAsync(Education education)
        {
            education.Id = _educations.Count > 0 ? _educations.Max(e => e.Id) + 1 : 1;
            _educations.Add(education);
            return Task.CompletedTask;
        }

        public Task UpdateEducationAsync(Education education)
        {
            var existing = _educations.FirstOrDefault(e => e.Id == education.Id);
            if (existing != null)
            {
                existing.Institution = education.Institution;
                existing.Degree = education.Degree;
                existing.StartYear = education.StartYear;
                existing.EndYear = education.EndYear;
            }
            return Task.CompletedTask;
        }

        public Task DeleteEducationAsync(int id)
        {
            var education = _educations.FirstOrDefault(e => e.Id == id);
            if (education != null)
            {
                _educations.Remove(education);
            }
            return Task.CompletedTask;
        }
    }
}

