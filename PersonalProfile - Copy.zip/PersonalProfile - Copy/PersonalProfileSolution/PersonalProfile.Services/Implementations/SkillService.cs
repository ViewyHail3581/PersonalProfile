﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PersonalProfile.Domain.Models;
using PersonalProfile.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonalProfile.Services.Implementations
{
    public class SkillService : ISkillService
    {
        private readonly List<Skill> _skills = new();

        public Task<Skill?> GetSkillAsync(int id)
        {
            var skill = _skills.FirstOrDefault(s => s.Id == id);
            return Task.FromResult(skill);
        }

        public Task<IEnumerable<Skill>> GetAllSkillsAsync()
        {
            return Task.FromResult<IEnumerable<Skill>>(_skills);
        }

        public Task AddSkillAsync(Skill skill)
        {
            skill.Id = _skills.Count > 0 ? _skills.Max(s => s.Id) + 1 : 1;
            _skills.Add(skill);
            return Task.CompletedTask;
        }

        public Task UpdateSkillAsync(Skill skill)
        {
            var existing = _skills.FirstOrDefault(s => s.Id == skill.Id);
            if (existing != null)
            {
                existing.Name = skill.Name;
            }
            return Task.CompletedTask;
        }

        public Task DeleteSkillAsync(int id)
        {
            var skill = _skills.FirstOrDefault(s => s.Id == id);
            if (skill != null)
            {
                _skills.Remove(skill);
            }
            return Task.CompletedTask;
        }
    }
}

